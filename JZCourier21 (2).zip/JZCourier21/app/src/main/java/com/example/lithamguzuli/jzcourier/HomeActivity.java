package com.example.lithamguzuli.jzcourier;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class HomeActivity extends AppCompatActivity {
    private Button Fair_estimateB,checkoutB;
    private FirebaseAuth.AuthStateListener mAuthListener;
     private FirebaseAuth mAuth;
    DatabaseReference mref;
    FirebaseDatabase database;
    FirebaseUser user;


    CheckBox fragile,non_fragile;
    EditText parcel_field;
    EditText contact_field,parcel_size;
    TextView parcel_estimate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        parcel_field=(EditText)findViewById(R.id.parconttext);
        parcel_size=(EditText)findViewById(R.id.editText3);
        contact_field=(EditText) findViewById(R.id.editText4);
        database=FirebaseDatabase.getInstance();
        String id=user.getUid();
        checkoutB=(Button) findViewById(R.id.checkoutButton);
        Fair_estimateB=(Button)findViewById(R.id.FairButton);
        fragile=(CheckBox)findViewById(R.id.checkBox3);
        non_fragile=(CheckBox)findViewById(R.id.checkBox2);
        parcel_estimate=(TextView) findViewById(R.id.textView);

        String parcel=parcel_field.getText().toString().trim();
        String number=contact_field.getText().toString().trim();
        String size=parcel_size.getText().toString().trim();
        int num=Integer.parseInt(number);
        final int sizee=Integer.parseInt(size);

        //Parcel p=new Parcel(id,number,size,time);
        //mref=database.getReference().child("Orders").push().child(Parcel);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                String TAG="checking";
                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };

        //String Users=getIntent().getExtras().getParcelable("Users");
      //  Toast.makeText(this,"hey",Toast.LENGTH_LONG).show();
        //textView.append(Users);


        checkoutB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HomeActivity.this,MapActivity.class);
                startActivity(intent);

            }
        });
        Fair_estimateB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 double price=0;
                double rate=5;
            if(fragile.isChecked()){
                price=40;
            }
            if (non_fragile.isChecked()){
                price =10;
            }
            price = price+(rate*sizee);
                String finalprice=Double.toString(price);
            parcel_estimate.setText(finalprice);

            }
        });
    }
}
