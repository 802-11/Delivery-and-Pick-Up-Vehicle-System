package com.example.lithamguzuli.jzcourier;

import android.os.SystemClock;

import java.sql.Time;

/**
 * Created by litha Mguzuli on 9/24/2017.
 */

public class Parcel {
    String id;
    long time;
    String fair_estimate;
    int phone_number_send,recieve_number;
    public Parcel(){

    }

    public Parcel(String id, String fair_estimate, int phone_number_send, int recieve_number) {
        this.id = id;
        this.time = time;
        this.fair_estimate = fair_estimate;
        this.phone_number_send = phone_number_send;
        this.recieve_number = recieve_number;
    }

    public String getId() {
        return id;
    }

    public long getTime() {
        time= System.currentTimeMillis();

        return time;
    }

    public String getFair_estimate() {
        return fair_estimate;
    }

    public int getPhone_number_send() {
        return phone_number_send;
    }

    public int getRecieve_number() {
        return recieve_number;
    }
}
