package com.example.lithamguzuli.jzcourier;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;

public class ConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

       /* PaymentsClient paymentsClient =
                Wallet.getPaymentsClient(
                        this,
                        new Wallet.WalletOptions.Builder()
                                .setEnvironment(WalletConstants.ENVIRONMENT_TEST)
                                .build());




        Intent intent=new Intent(this,MapActivity.class);
        startActivity(intent);*/
    }
}
